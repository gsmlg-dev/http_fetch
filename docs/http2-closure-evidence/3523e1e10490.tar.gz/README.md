# HTTP/2 F1/F2 follow-up evidence

Baseline commit: `ec53f21584b435d37768890b13c71a18a4584554` (0.15.0).
Frozen candidate tree: `3523e1e1049046e6c9f3592f6986c98465a60062`.
Freeze: `2026-09-30T17:59:25+08:00`.

This is local execution evidence, not remote CI or a release. The baseline
commit is unchanged. The tested source includes intentionally uncommitted
changes; use the candidate tree, not baseline HEAD, to identify the tested code.

All 42 current gates PASS. The Node TLS ex_ssl mixed soak completes 3,811
batches / 60,976 requests in 1,800,128 ms, seed 0, with one reused connection
and zero reservations. The independent source/ledger audit verifies 308
archived blobs and 306 workspace blobs. Full umbrella tests pass: 687 tests,
20 doctests, zero failures and three existing gated QUIC skips. Detailed sampled
resource maxima are recorded in `acceptance-audit.json` and the report.

## Contents and evidence boundary

- `candidate-source.tar.gz`: exact frozen source bytes and modes.
- `provenance.txt`, `candidate.index`: tree, baseline, freeze time and lock digest.
- `run-final-gates.py`: actual command recorder, using the historical ledger's
  unchanged 42 commands. Original absolute temporary paths are retained.
- `results.tsv`, `final-*.log`: current candidate's exact commands, start times,
  actual outputs, exit statuses and durations. Only these gates count toward
  final acceptance. An exit status alone does not establish soak completion.
- `audit-final-evidence.py`, `acceptance-audit.json`: derived checks of all
  required gate records, explicit workload completion, resource samples,
  source-archive hashes/modes, workspace source parity and unchanged HEAD.
- `f1.patch`: early-response upload shutdown, scheduler idempotence and
  wire/public-fetch regressions, including the stronger owner-held-chunk case.
- `f2.patch`: queued connector promotion, production SocketClient integration
  and deterministic regressions including a saturated surviving sibling.
- `fixture-barriers.patch`: deterministic response-release and ticket-warming
  fixture barriers; not a production pooling workaround.
- `f2-partial-owner-red.log`: two new failing owner-DOWN/draining cases before
  the partial-owner promotion repair. `followup-regressions-green.log` records
  the corrected 67-test follow-up suite, before final candidate freeze.
- `resumption-fixture-red.log`: deterministic fixture reproduction before its
  repair. The full clean-package gates validate the final fixture and runtime.
- `historical-baseline-red/`: copied original pre-fix failures for F1/F2 and
  scheduler cleanup. These are historical red evidence, NOT current acceptance.
- `attempt-05167114f0c1/`: rejected intermediate candidate. Its nested
  `attempt-cc5ba68d54c6/` is also rejected. Incomplete/interrupted soaks from
  either attempt do not satisfy the 30-minute requirement.
- `published-exssl-final/`: current published dependency consumer reports.
- `validation-report.md`: reporting-only final report snapshot, written after
  the tested source freeze.
- `MANIFEST.sha256`: checksum of each payload file, excluding the manifest
  itself. Raw text logs retain terminal escapes and are not reconstructed.

## Reproduction

Use Elixir 1.18.5, OTP 28.5.0.5 / ERTS 16.4.0.5, Node 24.19.0 /
nghttp2 1.69.0, and Python peers pinned by
`scripts/requirements-http2-interop.txt` (hyper-h2 4.2.0, hpack 4.1.0,
hyperframe 6.1.0). Extract `candidate-source.tar.gz` into an empty directory
and resolve locked dependencies with `mix deps.get --check-locked` in test
environment. Use a fresh Mix build directory. Each final log contains the
exact command, including test seeds and scheduler/max-case settings.

The runner resolves command templates from the separate historical archive
`docs/http2-closure-evidence/e762dc80ddaf.tar.gz`; extract that archive and
adjust the runner's original absolute paths when reproducing elsewhere. This
is template reuse only: every current command is freshly executed and recorded
against the frozen follow-up tree. Do not count the old ledger as a new result.

To verify the payload after extraction, run `sha256sum -c MANIFEST.sha256`.
The source/workspace audit additionally needs the original repository's Git
objects and paths; adapt its repository path if running elsewhere.

Neither the reporting document nor the evidence archive is executable source.
They are written after freeze; the audit excludes only the reporting document
and the user's pre-existing deletion of `CODEX_HTTP2_PROMPT.md` from workspace
parity. No commit, push, merge, release, publication, deployment, remote
workflow dispatch or artifact upload is performed.
