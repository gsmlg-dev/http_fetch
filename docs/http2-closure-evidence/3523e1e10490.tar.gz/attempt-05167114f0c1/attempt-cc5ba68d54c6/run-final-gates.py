import concurrent.futures
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import threading
import time


evidence = Path(sys.argv[1])
candidate = Path(sys.argv[2])
tree = sys.argv[3]
previous = Path('/tmp/http-fetch-closure-archive-e762dc80ddaf')
environment = os.environ.copy()
environment.update(
    HTTP_FETCH_CANDIDATE_TREE=tree,
    MIX_ENV='test',
    MIX_BUILD_PATH=f'/tmp/http-fetch-closure-final-{tree[:12]}-build',
    MIX_DEPS_PATH='/home/gao/Workspace/gsmlg-dev/http_fetch/deps',
    GIT_DIR='/home/gao/Workspace/gsmlg-dev/http_fetch/.git',
    GIT_WORK_TREE=str(candidate),
    HTTP2_PEER_PYTHON='/tmp/http2-production-peer-venv/bin/python',
)
result_lock = threading.Lock()
stopped = threading.Event()
commands = {}
for record in (previous / 'results.tsv').read_text().splitlines():
    gate = record.split('\t')[0]
    command_line = next(
        line[len('command='):]
        for line in (previous / f'{gate}.log').read_text().splitlines()
        if line.startswith('command=')
    )
    commands[gate] = [
        argument.replace('/tmp/http-fetch-closure-evidence', str(evidence))
        for argument in shlex.split(command_line)
    ]


def run_gate(gate):
    if stopped.is_set():
        return gate, None
    command = commands[gate]
    started = time.time_ns()
    with (evidence / f'{gate}.log').open('w') as logfile:
        logfile.write(
            f'candidate_tree={tree}\nbaseline_commit=ec53f21584b435d37768890b13c71a18a4584554\n'
            f'command={shlex.join(command)}\nstart_epoch_ns={started}\n'
        )
        logfile.flush()
        process = subprocess.run(
            command, cwd=candidate, env=environment,
            stdout=logfile, stderr=subprocess.STDOUT,
        )
        elapsed = (time.time_ns() - started) // 1_000_000
        logfile.write(f'\nexit_status={process.returncode}\nelapsed_ms={elapsed}\n')
    with result_lock:
        with (evidence / 'results.tsv').open('a') as ledger:
            ledger.write(f'{gate}\t{process.returncode}\t{elapsed}\t{tree}\n')
        print(f'{gate}: exit={process.returncode}, elapsed_ms={elapsed}', flush=True)
    if process.returncode != 0:
        stopped.set()
    return gate, process.returncode


for prerequisite in ('final-deps', 'final-compile', 'final-format'):
    if run_gate(prerequisite)[1] != 0:
        sys.exit(1)

remaining = [gate for gate in commands if gate not in (
    'final-deps', 'final-compile', 'final-format', 'final-soak',
)]
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
    futures = [executor.submit(run_gate, gate) for gate in ['final-soak', *remaining]]
    outcomes = [future.result() for future in concurrent.futures.as_completed(futures)]
if any(status != 0 for _, status in outcomes):
    print('FAIL or NOT RUN: inspect results.tsv and failed logs', flush=True)
    sys.exit(1)
print(json.dumps({'result': 'PASS', 'gates': len(commands), 'candidate_tree': tree}), flush=True)
