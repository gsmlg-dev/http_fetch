import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile


evidence = Path(sys.argv[1])
tree = sys.argv[2]
repository = Path('/home/gao/Workspace/gsmlg-dev/http_fetch')
expected = {'final-' + gate for gate in (
    'deps', 'compile', 'format', 'credo', 'dialyzer', 'full-tests',
    'cold-fetch-repeat-1', 'cold-fetch-repeat-2', 'cold-fetch-repeat-3',
    'tls-lifecycle-ci', 'external-consumer', 'exssl-feature-consumer',
    'package-tls-ssl', 'package-tls-ex_ssl', 'hpack', 'runtime-regressions',
    'environment', 'soak',
)}
expected.update(
    f'final-{mode}-{peer}-{transport}'
    for mode in ('smoke', 'transfer', 'concurrent')
    for peer in ('hyper-h2', 'node')
    for transport in ('h2c', 'tls-ssl', 'tls-ex_ssl')
)
expected.update(
    f'final-reuse-{peer}-limit-{limit}'
    for peer in ('hyper-h2', 'node') for limit in (1, 2, 100)
)
rows = [record.split('\t') for record in (evidence / 'results.tsv').read_text().splitlines()]
assert len(rows) == len(expected) == 42
assert {record[0] for record in rows} == expected
for gate, status, elapsed, candidate in rows:
    assert status == '0' and candidate == tree, (gate, status, candidate)
    text = (evidence / f'{gate}.log').read_text()
    assert f'candidate_tree={tree}' in text
    assert 'exit_status=0' in text and int(elapsed) > 0
    assert 'command=' in text and 'start_epoch_ns=' in text
    if gate.startswith(('final-smoke-', 'final-transfer-', 'final-concurrent-', 'final-reuse-')) or gate == 'final-soak':
        records = [json.loads(line) for line in text.splitlines() if line.startswith('{')]
        assert any(record.get('result') == 'PASS' for record in records), gate

soak_records = [
    json.loads(line)
    for line in (evidence / 'final-soak.log').read_text().splitlines()
    if line.startswith('{')
]
completion = next(
    record for record in soak_records
    if record.get('mode') == 'soak' and record.get('result') == 'PASS'
)
workload = next(record for record in soak_records if record.get('gate') == 'soak_workload')
assert completion['elapsed_ms'] >= 1_800_000
assert completion['reservations'] == 0 and completion['connections'] == 1
assert workload['requests'] == workload['batches'] * 16
samples = [
    record for record in soak_records
    if record.get('gate') in ('soak_sample', 'resource_snapshot')
]
owners = [owner for sample in samples for owner in sample['owners']]
assert all(
    owner['active_streams'] == owner['protocol_streams'] == owner['mailbox'] == 0
    for owner in owners
)
assert all(owner['heap_bytes'] <= 8 * 1024 * 1024 for owner in owners)
assert all(owner['binary_bytes'] <= 2 * 1024 * 1024 for owner in owners)

full_test_text = (evidence / 'final-full-tests.log').read_text()
test_counts = re.findall(r'(?m)^(?:(\d+) doctests, )?(\d+) tests, 0 failures(?:, (\d+) skipped)?$', full_test_text)
summary = {
    'candidate_tree': tree,
    'kind': 'derived audit of actual command logs and immutable source bytes',
    'completed_gates': len(rows),
    'full_suite': {
        'tests': sum(int(tests) for _, tests, _ in test_counts),
        'doctests': sum(int(doctests or 0) for doctests, _, _ in test_counts),
        'skips': sum(int(skips or 0) for _, _, skips in test_counts),
    },
    'soak_completion': completion,
    'soak_workload': workload,
    'logged_resource_samples': len(samples),
    'logged_maxima': {
        'beam_memory': max(sample['beam_memory'] for sample in samples),
        'process_count': max(sample['process_count'] for sample in samples),
        'pool_keys': max(sample['pool_keys'] for sample in samples),
        **{
            measurement: max(owner[measurement] for owner in owners)
            for measurement in ('active_streams', 'protocol_streams', 'mailbox', 'heap_bytes', 'binary_bytes')
        },
    },
}
assert summary['full_suite'] == {'tests': 687, 'doctests': 20, 'skips': 3}

entries = subprocess.check_output(['git', 'ls-tree', '-r', '-z', tree], cwd=repository).split(b'\0')
checked = 0
archived = 0
with tarfile.open(evidence / 'candidate-source.tar.gz', 'r:gz') as source_archive:
    for entry in entries:
        if not entry:
            continue
        metadata, filename = entry.split(b'\t', 1)
        mode, kind, blob = metadata.decode().split()
        relative = filename.decode()
        assert kind == 'blob', relative
        archived_entry = source_archive.getmember(relative)
        data = archived_entry.linkname.encode() if mode == '120000' else source_archive.extractfile(archived_entry).read()
        digest = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
        assert digest == blob, ('archived source', relative)
        assert bool(archived_entry.mode & 0o111) == (mode in ('100755', '120000')), relative
        archived += 1
        if relative in ('CODEX_HTTP2_PROMPT.md', 'docs/http2-production-validation.md'):
            continue
        filepath = repository / relative
        data = filepath.readlink().as_posix().encode() if mode == '120000' else filepath.read_bytes()
        digest = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
        assert digest == blob, ('workspace', relative)
        checked += 1
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repository).decode().strip() == 'ec53f21584b435d37768890b13c71a18a4584554'
summary['workspace_blobs_checked'] = checked
summary['archived_source_blobs_checked'] = archived
(evidence / 'acceptance-audit.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
print(f'PASS: 42 complete gates; {checked} workspace blobs and {archived} archived source blobs match')
