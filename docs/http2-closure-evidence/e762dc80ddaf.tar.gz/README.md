# HTTP/2 closure evidence

Baseline commit: `ec53f21584b435d37768890b13c71a18a4584554`.
Final tested tree: `e762dc80ddaf50ef546940798aabf2ef78934e66`.

This is local evidence, not a remote CI artifact upload or a new release.

All 42 final gates completed successfully. The full Node TLS ex_ssl soak
completed 3,846 batches / 61,536 requests in 1,800,145 ms, seed 0, with an
explicit PASS and zero remaining reservations. Historical failures and stopped
attempts are retained separately and never counted as final acceptance.

## Contents

- `candidate-source.tar.gz`: exact immutable source archive from the final tree.
- `candidate.env`, `provenance.txt`: original paths, locked dependency digest and candidate identity.
- `run-gate.sh`: command/status/runtime recorder; `results.tsv`: each actual final invocation.
- `final-*.log`: complete final-gate output, exact commands, seeds, versions, exit statuses and durations.
- `runtime-closure.patch`, `gate-repairs.patch`: independently reviewable change groups against the baseline.
- `executable-parity.txt`: comparison of 271 current executable/test/configuration/fixture files with the frozen tree, including Git symlink blobs.
- `final-source-parity.txt`: final comparison of 306 candidate blobs with the workspace, excluding only the reporting document and user-owned prompt deletion.
- `audit-final-evidence.py`, `acceptance-audit.json`: checks all 42 required final results and explicit soak completion, and derives sampled resource maxima from actual log records.
- `MANIFEST.sha256`: checksums of the archived payload; terminal ANSI/control sequences in text logs are sanitized, without reconstructing or changing their outcomes.
- `observed-*.log` and `observed-*-run.json`: read-only retrieval of the reported historical CI failures and job outcomes.
- `f1-red.log`, `f2-red.log`, `f2-registered-red.log`, `scheduler-red.log`, `peer-port-red.log`: actual regression failures before their corresponding fixes.
- `historical-lifecycle-*.log`: fresh-build reproduction on reviewed `e24c4a1`, including two occurrences of the original 200-ms pre-header expiry failure with seed 342781/max_cases 8/four schedulers.
- `timing-diagnosis.exs` and `.log`: controlled scheduling-budget diagnosis for OwnerMonitor, separately from pre-header HTTP/2 timer expiry.
- `admission-trace.exs` and `.log`: diagnostic tracing, not acceptance; it changes scheduling and exposed a fixture's restored-owner/stale-pool-capacity race.
- `published-exssl-final/*.txt`: sanitized nine-group feature, fixture and runtime provenance reports.
- `attempt-b88541f98de1/`: rejected candidate with a failed mixed-traffic soak that exposed non-idempotent scheduler removal.
- `attempt-368960c1fa20/`: rejected candidate with concurrent-suite fixture failures; its soak and one reuse workload were explicitly stopped, not accepted.

An interrupted BEAM shutdown may return exit status zero without a completed
workload. In particular, the second attempted soak is NOT PASS. Final interop
acceptance requires the workload's explicit PASS record and the full requested
duration. A passing small diagnostic soak is never substituted for 30 minutes.

## Reproduction

Use Elixir 1.18.5/OTP 28, Node 24.19.0/nghttp2 1.69.0 and Python peers pinned by
`scripts/requirements-http2-interop.txt`. Extract `candidate-source.tar.gz` into
a fresh source directory, use a fresh Mix build path, and resolve `mix.lock` with
`mix deps.get --check-locked`. Each final log provides the exact command and
environment-bearing arguments to rerun. The original runner retains absolute
paths for audit; adapt `candidate.env` and its evidence-directory references
when reproducing on another machine. Do not mistake the baseline HEAD printed
in logs for the uncommitted tested tree.

The candidate was frozen before the validation report/evidence archive were
written. Those subsequent additions are reporting-only; executable parity is
checked separately. No historical raw log was reconstructed from a summary.
