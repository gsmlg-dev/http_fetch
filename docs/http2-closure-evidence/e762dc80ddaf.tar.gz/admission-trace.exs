tracer = spawn(fn ->
  loop = fn loop ->
    receive do
      {:trace, caller, :call, {HTTP.HTTP2.Pool, function, arguments}} ->
        details = Enum.take(arguments, 3)
        IO.puts("ADMISSION_CALL #{inspect(caller)} #{function} #{inspect(details, limit: 12)}")
        loop.(loop)
      {:trace, caller, :call, {HTTP.HTTP2.ConnectionOwner, function, [owner | arguments]}} ->
        IO.puts("OWNER_CALL #{inspect(caller)} #{function} #{inspect(owner)} #{inspect(arguments, limit: 3)}")
        loop.(loop)
      {:trace, caller, :return_from, {module, function, _arity}, result} ->
        IO.puts("TRACE_RETURN #{inspect(caller)} #{inspect(module)} #{function} #{inspect(result, limit: 8)}")
        loop.(loop)
      _ -> loop.(loop)
    end
  end
  loop.(loop)
end)
for {module, function, arity} <- [
  {HTTP.HTTP2.Pool, :register, 4},
  {HTTP.HTTP2.Pool, :reserve, 3},
  {HTTP.HTTP2.Pool, :try_reserve, 2},
  {HTTP.HTTP2.ConnectionOwner, :open_stream, 3}
] do
  :erlang.trace_pattern({module, function, arity}, [{:_, [], [{:return_trace}]}], [])
end
:erlang.trace(:all, true, [:call, {:tracer, tracer}])
Mix.Task.run("test", ["apps/http_fetch/test", "--seed", "342781", "--max-cases", "8"])
