import hashlib
import json
import pathlib
import subprocess
import tarfile

root = pathlib.Path('/tmp/http-fetch-closure-evidence')
repo = pathlib.Path('/home/gao/Workspace/gsmlg-dev/http_fetch')
tree = 'e762dc80ddaf50ef546940798aabf2ef78934e66'
expected = {'final-' + name for name in (
    'deps', 'compile', 'format', 'credo', 'dialyzer', 'full-tests',
    'cold-fetch-repeat-1', 'cold-fetch-repeat-2', 'cold-fetch-repeat-3',
    'tls-lifecycle-ci', 'external-consumer', 'exssl-feature-consumer',
    'package-tls-ssl', 'package-tls-ex_ssl', 'hpack', 'runtime-regressions',
    'environment', 'soak')}
expected.update(f'final-{mode}-{peer}-{transport}'
                for mode in ('smoke', 'transfer', 'concurrent')
                for peer in ('hyper-h2', 'node')
                for transport in ('h2c', 'tls-ssl', 'tls-ex_ssl'))
expected.update(f'final-reuse-{peer}-limit-{limit}'
                for peer in ('hyper-h2', 'node') for limit in (1, 2, 100))
rows = [line.split('\t') for line in (root / 'results.tsv').read_text().splitlines()]
assert len(rows) == len(expected) == 42
assert {row[0] for row in rows} == expected
for gate, status, runtime, candidate in rows:
    assert status == '0' and candidate == tree, (gate, status, candidate)
    text = (root / f'{gate}.log').read_text()
    assert f'candidate_tree={tree}' in text and 'exit_status=0' in text
    assert int(runtime) > 0
    if gate.startswith(('final-smoke-', 'final-transfer-', 'final-concurrent-', 'final-reuse-')) or gate == 'final-soak':
        records = [json.loads(line) for line in text.splitlines() if line.startswith('{')]
        assert any(record.get('result') == 'PASS' for record in records), gate

records = [json.loads(line) for line in (root / 'final-soak.log').read_text().splitlines() if line.startswith('{')]
completion = next(record for record in records if record.get('mode') == 'soak' and record.get('result') == 'PASS')
workload = next(record for record in records if record.get('gate') == 'soak_workload')
assert completion['elapsed_ms'] >= 1800000
assert completion['reservations'] == 0 and completion['connections'] == 1
assert workload['requests'] == workload['batches'] * 16
samples = [record for record in records if record.get('gate') in ('soak_sample', 'resource_snapshot')]
owners = [owner for sample in samples for owner in sample['owners']]
summary = {
    'kind': 'derived summary of actual final-soak.log JSON records',
    'candidate_tree': tree,
    'completed_gates': len(rows),
    'soak_completion': completion,
    'soak_workload': workload,
    'logged_resource_samples': len(samples),
    'logged_maxima': {
        'beam_memory': max(sample['beam_memory'] for sample in samples),
        'process_count': max(sample['process_count'] for sample in samples),
        'pool_keys': max(sample['pool_keys'] for sample in samples),
        **{name: max(owner[name] for owner in owners) for name in
           ('active_streams', 'protocol_streams', 'mailbox', 'heap_bytes', 'binary_bytes')}
    }
}
(root / 'acceptance-audit.json').write_text(json.dumps(summary, indent=2) + '\n')

entries = subprocess.check_output(['git', 'ls-tree', '-r', '-z', tree], cwd=repo).split(b'\0')
checked = 0
archive_checked = 0
source_archive = tarfile.open(root / 'candidate-source.tar.gz', 'r:gz')
for entry in entries:
    if not entry:
        continue
    metadata, filename = entry.split(b'\t', 1)
    mode, kind, blob = metadata.decode().split()
    relative = filename.decode()
    archived_entry = source_archive.getmember(relative)
    archived_data = archived_entry.linkname.encode() if mode == '120000' else source_archive.extractfile(archived_entry).read()
    archived_digest = hashlib.sha1(f'blob {len(archived_data)}\0'.encode() + archived_data).hexdigest()
    assert archived_digest == blob, ('source archive', relative)
    assert bool(archived_entry.mode & 0o111) == (mode in ('100755', '120000')), ('source mode', relative)
    archive_checked += 1
    if relative in ('CODEX_HTTP2_PROMPT.md', 'docs/http2-production-validation.md'):
        continue
    filepath = repo / relative
    if kind != 'blob':
        continue
    data = filepath.readlink().as_posix().encode() if mode == '120000' else filepath.read_bytes()
    digest = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
    assert digest == blob, relative
    checked += 1
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == 'ec53f21584b435d37768890b13c71a18a4584554'
(root / 'final-source-parity.txt').write_text(f'PASS: {checked} candidate blobs match current workspace. Only user-owned prompt deletion and reporting document excluded.\nCandidate tree: {tree}\n')
print(json.dumps(summary, indent=2))
print(f'PASS: 42 complete gates; {checked} workspace blobs and {archive_checked} archived source blobs match candidate')
