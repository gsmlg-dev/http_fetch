parent = self()
Task.start_link(fn ->
  Code.eval_file(Path.join(System.fetch_env!("CANDIDATE_DIR"), "scripts/http2_production_gate.exs"))
  send(parent, :complete)
end)
for sample <- 1..12 do
  receive do
    :complete -> IO.puts("completed before sample"); exit(:normal)
  after
    1_000 -> :ok
  end
  pool = :sys.get_state(:http_fetch_http2_pool)
  owners = DynamicSupervisor.which_children(:http_fetch_http2_connection_supervisor)
  data = for {_, owner, _, _} <- owners do
    state = :sys.get_state(owner)
    streams = for {id, entry} <- state.streams do
      stream = state.connection.streams[id]
      bridge = if is_pid(entry.body_bridge), do: HTTP.HTTP2.BodyBridge.status(entry.body_bridge)
      %{id: id, send_window: stream.send_window, sent_end: stream.end_stream_sent?,
        response: stream.response_phase, pending_bytes: case entry.pending_body do
          {_, bytes, _} -> byte_size(bytes)
          _ -> 0
        end, bridge: bridge, upload_stopped: entry.upload_stopped?}
    end
    %{owner: inspect(owner), connection_window: state.connection.connection_send_window,
      streams: streams, mailbox: elem(Process.info(owner, :message_queue_len), 1)}
  end
  IO.puts(inspect(%{sample: sample, pool: HTTP.HTTP2.Pool.stats(:http_fetch_http2_pool),
    reservations: map_size(pool.reservations), owners: data}, limit: :infinity, pretty: true))
end
receive do: (:complete -> :ok)
