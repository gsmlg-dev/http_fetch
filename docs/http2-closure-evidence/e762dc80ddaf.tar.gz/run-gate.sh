#!/usr/bin/env bash
set -uo pipefail
source /tmp/http-fetch-closure-evidence/candidate.env
cd "$CANDIDATE_DIR"
gate=$1
shift
log="/tmp/http-fetch-closure-evidence/$gate.log"
started=$(date +%s%N)
{
  printf 'candidate_tree=%s\nbaseline_commit=%s\n' "$HTTP_FETCH_CANDIDATE_TREE" "$(git rev-parse HEAD)"
  printf 'command='
  printf '%q ' "$@"
  printf '\nstart_epoch_ns=%s\n' "$started"
  "$@"
  status=$?
  ended=$(date +%s%N)
  elapsed_ms=$(( (ended - started) / 1000000 ))
  printf '\nexit_status=%s\nelapsed_ms=%s\n' "$status" "$elapsed_ms"
  printf '%s\t%s\t%s\t%s\n' "$gate" "$status" "$elapsed_ms" "$HTTP_FETCH_CANDIDATE_TREE" >> /tmp/http-fetch-closure-evidence/results.tsv
  exit "$status"
} > "$log" 2>&1
