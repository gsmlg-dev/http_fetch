ExUnit.start(seed: 342781, max_cases: 8)
Code.require_file("apps/http_fetch/test/support/http2_scripted_peer.ex")

defmodule ClosureTimingDiagnosis do
  use ExUnit.Case, async: false
  alias HTTP.Test.HTTP2ScriptedPeer, as: Peer

  test "controlled fixture scheduling exhausts the original 100-ms readiness observation budget" do
    observer = self()
    owner = spawn(fn -> receive do: (:stop -> :ok) end)
    connection = spawn(fn ->
      receive do: (:begin -> :ok)
      guardian = HTTP.OwnerMonitor.start(self(), owner)
      send(observer, {:watching, guardian})
      receive do: (:never -> :ok)
    end)
    on_exit(fn -> Process.exit(owner, :kill); Process.exit(connection, :kill) end)
    started = System.monotonic_time(:millisecond)
    refute_receive {:watching, _}, 100
    elapsed = System.monotonic_time(:millisecond) - started
    assert elapsed >= 100
    send(connection, :begin)
    assert_receive {:watching, guardian}, 5_000
    connection_monitor = Process.monitor(connection)
    guardian_monitor = Process.monitor(guardian)
    send(owner, :stop)
    assert_receive {:DOWN, ^connection_monitor, :process, ^connection, :shutdown}, 5_000
    assert_receive {:DOWN, ^guardian_monitor, :process, ^guardian, _}, 5_000
    IO.puts("controlled_owner_monitor_readiness_elapsed_ms=#{elapsed}; runtime_shutdown_contract=PASS")
  end

  test "the original 200-ms deadline correctly expires before deliberately gated response headers" do
    observer = self()
    {url, peer} = Peer.start(observer, fn socket ->
      {id, true} = Peer.request(socket)
      send(observer, {:request_ready, self(), id})
      receive do: (:finish -> :ok)
    end)
    started = System.monotonic_time(:millisecond)
    promise = HTTP.fetch(url, http_version: :h2c, timeout: 200)
    assert_receive {:request_ready, ^peer, _}, 5_000
    result = HTTP.Promise.await(promise)
    assert {:error, :request_timeout} = result
    assert_raise KeyError, fn -> result.status end
    elapsed = System.monotonic_time(:millisecond) - started
    IO.puts("controlled_preheader_result=#{inspect(result)}; elapsed_ms=#{elapsed}; original_status_assertion=KeyError")
    send(peer, :finish)
    assert_receive {:peer_complete, ^peer}, 5_000
    send(peer, :close)
  end
end
