import hashlib
import pathlib
import subprocess
import sys

root = pathlib.Path('<repository>')
build = pathlib.Path('/tmp/http-stream-clients-p4-audit-build')
kind, output = sys.argv[1:]
if kind == 'source':
    roots = ['apps', 'config', 'scripts', '.github', 'mix.exs', 'mix.lock', '.formatter.exs', '.credo.exs', '.dialyzer_ignore.exs']
    names = subprocess.check_output(['rg', '--files', '--hidden'] + [name for name in roots if (root / name).exists()], cwd=root, text=True).splitlines()
    excluded = {'tmp', '__pycache__', 'plts', '_build', 'deps', 'doc', 'docs', '.git', '.trees', 'coverage'}
    files = [(name, root / name) for name in names if not (set(pathlib.Path(name).parts) & excluded)]
else:
    files = [(str(path.relative_to(build)), path) for path in build.rglob('*.beam')]
with open(output, 'w') as handle:
    for name, path in sorted(files):
        handle.write(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {name}\n')
print(f'{kind}: {len(files)} files, manifest sha256 {hashlib.sha256(pathlib.Path(output).read_bytes()).hexdigest()}')
