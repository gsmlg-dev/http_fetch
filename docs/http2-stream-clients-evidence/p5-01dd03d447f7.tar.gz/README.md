# P5 executable acceptance evidence

Candidate commit: d99b9de655b3367c91eea0d59af14cc4b0afa7a7
Git tree: 01dd03d447f709b27dea32f74d95050edadfbc18
Version: 0.16.0. All 42 Fetch and 36 new acceptance gates passed.

source/ is the complete candidate Git archive, including symlinks and historical archives. acceptance/ contains raw commands, ledgers, results, frozen budgets, samples, peer observations, source and unchanged 646-module BEAM manifests. Dependency/build directories are omitted. audit.json independently validates captured workload/wire completion and resources; stream-audit.txt is the separate stream audit. The captured environment gate records pinned peer/toolchain versions.

Mixed soak: active 1800103 ms, 3285 WS/3288 SSE messages and 1643 Fetch requests, with slow-consumer/cancellation/draining intervals and zero final logical streams, reservations, admissions, workers, monitors and sessions. Eligible idle connection owners may remain. Fetch soak: 61712 requests, 1800161 ms, zero reservations and active/protocol streams.

preparation/ is separate preparatory evidence, including red/green policy and fixture checks, runner interruption and source guards. failed-9d2f6fb/ preserves the failed/interrupted first candidate; it is NOT accepted. source-from-final.patch reconstructs its source from the final candidate. Short checks marked acceptance:false never establish 30-minute acceptance.

The source-manifest JSON hashes symlink target strings; SHA256SUMS hashes normal file bytes and symlink target strings. BEAM manifests prove unchanged compiled objects but builds are not included. Samples are sampled maxima, not continuous peaks. SSE EOF/Open counts and final settling are source-contract assertions corroborated by ordered wire ranges/cursors and owner-only final samples.

Re-audit without running workloads:
python3 tools/acceptance-audit.py --evidence acceptance --parentlog acceptance/acceptance.log --output re-audit.json
Reproduce workloads using the source/scripts/http2_stream_clients_acceptance.py entrypoint and a clone containing the candidate tree, with the pinned peer environment. See source/docs/http2-stream-clients-validation.md.

Remote candidate CI36781638609 (14 jobs) and Test36781638418 (7 app jobs) passed. Later evidence/docs-only commits preserve executable candidate files. Release/publication and fresh Hex consumers are verified separately after this archive is committed. No production rollout was performed.
