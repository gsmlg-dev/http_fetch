# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is an Elixir library providing a browser-like HTTP fetch API built on Erlang's `:gen_tcp` and `:ssl` modules. It implements Promise-based async operations with request cancellation, streaming support, and comprehensive telemetry integration.

## Core Architecture

### Main Modules
- **HTTP** (`apps/http_fetch/lib/http.ex`): Entry point providing `fetch/2` function. Handles async request execution via Task.Supervisor, response processing (including streaming detection), and telemetry event emission
- **HTTP.Promise** (`apps/http_fetch/lib/http/promise.ex`): JavaScript-like Promise implementation wrapping Task with chaining via `then/3` and `await/2`
- **HTTP.Request** (`apps/http_core/lib/http/request.ex`): Request configuration struct that serializes to HTTP/1.1 wire iodata
- **HTTP.HTTP1** (`apps/http_core/lib/http/http1.ex`): Pure HTTP/1.1 serializer and response parser for status, headers, Content-Length, chunked bodies, and read-to-close bodies
- **HTTP.SocketClient** (`apps/http_fetch/lib/http/socket_client.ex`): Socket owner process for one request lifecycle, including TCP/TLS/Unix transport selection, redirects, streaming, deadlines, and aborts
- **HTTP.Response** (`apps/http_fetch/lib/http/response.ex`): Response struct with `json/1`, `text/1`, and `write_to/2` methods. Handles both buffered and streamed responses
- **HTTP.Headers** (`apps/http_core/lib/http/headers.ex`): Headers manipulation with case-insensitive operations, Content-Type parsing, and default User-Agent support
- **HTTP.FormData** (`apps/http_core/lib/http/form_data.ex`): Multipart/form-data encoding with file upload support
- **HTTP.Blob** (`apps/http_core/lib/http/blob.ex`): Browser-like binary blob data type shared by Fetch and WebSocket APIs
- **HTTP.Transport** (`apps/http_core/lib/http/transport.ex`): Shared TCP, TLS, and Unix socket transport behaviour and implementations
- **HTTP.AbortController** (`apps/http_fetch/lib/http/abort_controller.ex`): Request cancellation via Agent-based controller
- **HTTP.FetchOptions** (`apps/http_fetch/lib/http/fetch_options.ex`): Options processing and validation for `fetch/2`
- **HTTP.Telemetry** (`apps/http_fetch/lib/http/telemetry.ex`): Comprehensive telemetry events for requests, responses, streaming, and errors
- **QuicHttp3** (`apps/elixir_quic_http3/lib/quic_http3.ex`): HTTP/3 application-layer boundary over generic QUIC transports; it does not replace the legacy `:quic_h3` backend yet

### Application Structure
- This is a Mix umbrella with independent protocol apps under `apps/`.
- Shared HTTP primitives live in `apps/http_core`; pooled HTTP/2 connection
  ownership and stream I/O live in `apps/http_runtime`. Fetch, EventSource and
  WebSocket depend on both shared applications instead of each other.
- `apps/elixir_quic_http3` owns the future HTTP/3/QPACK session layer and
  depends on `:elixir_quic`; it must not move HTTP/3 semantics into the QUIC
  transport library.
- **HTTPFetch.Application** (`apps/http_fetch/lib/http_fetch.ex`): Supervision tree with `:http_fetch_task_supervisor` Task.Supervisor and HTTP.AbortController Registry

### Key Design Patterns
1. **Async by default**: All requests use Task.Supervisor with `async_nolink/4`
2. **Streaming threshold**: Responses >5MB or with unknown Content-Length automatically stream via `HTTP.Stream`
3. **Telemetry instrumentation**: All operations emit `:telemetry` events (`:http_fetch` prefix) for monitoring and observability
4. **Error propagation**: Expected transport and parser failures return `{:error, reason}` tuples for consistent API behavior

## Development Commands

```bash
# Install dependencies
mix deps.get

# Run all tests
mix test

# Run specific test file
mix test apps/http_fetch/test/http/response_test.exs

# Run specific test by line number
mix test apps/http_fetch/test/http/response_test.exs:42

# Interactive development with application started
iex -S mix

# Compile project
mix compile

# Format all code
mix format

# Check formatting without making changes
mix format --check-formatted

# Run Credo code analysis (standard checks)
mix credo

# Run Credo with strict mode (includes readability checks)
mix credo --strict

# Explain a specific Credo issue
mix credo explain <issue_category>

# Run Dialyzer type checking
mix dialyzer

# Generate/rebuild Dialyzer PLT (takes 2-3 minutes)
mix dialyzer --plt

# Build documentation
mix docs

# Production build
MIX_ENV=prod mix compile
```

For individual app tests, stay at the umbrella root: run `MIX_ENV=test mix
deps.get`, `MIX_ENV=test mix compile --warnings-as-errors`, then `mix test
apps/<app>/test`. Running Mix inside a child app does not traverse the runtime
dependencies of its `in_umbrella` dependencies. E2E uses the same root preparation
and `mix test apps/<app>/e2e`, or `mix test.e2e` for all E2E suites.
Run `bash scripts/external_consumer_smoke.sh` to build all seven packages
(`http_core`, `http_runtime`, `elixir_quic_http3`, `http_fetch`, `http_web_socket`,
`http_event_source`, and `http_web_transport`) and
verify an isolated non-umbrella consumer, including transitive TLS dependencies.

## Important Implementation Details

### Request Options Mapping
- `fetch/2` accepts flat fetch init options. Use `method`, `headers`, `body`, `signal`, and `redirect` for browser-style options.
- Socket transport extensions are also flat: `timeout`, `connect_timeout`, `ssl`, `socket_opts`, and `unix_socket`.

### Streaming Behavior
- Automatic streaming for responses >5MB or unknown Content-Length
- Stream process receives decoded body chunks from the socket owner
- Stream messages: `{:stream_chunk, pid, data}`, `{:stream_end, pid}`, `{:stream_error, pid, reason}`
- Streaming uploads pass an `HTTP.Stream` PID as `body` with `duplex: "half"`; this currently uses HTTP/1.1 chunked request framing

### Response Body Handling
- `HTTP.Response.write_to/2` handles both buffered (direct binary write) and streamed responses (receive loop)
- Streamed responses expose the stream PID in `body`; `stream: pid` remains as a compatibility alias

### Telemetry Events
All events use `[:http_fetch, ...]` prefix:
- `[:request, :start]` - measurements: `start_time`; metadata: `method`, `url`, `headers`
- `[:request, :stop]` - measurements: `duration`, `status`, `response_size`; metadata: `url`, `status`
- `[:request, :exception]` - measurements: `duration`; metadata: `url`, `error`
- `[:streaming, :start]`, `[:streaming, :chunk]`, `[:streaming, :stop]` - for streaming operations

## Dependencies
- **telemetry** (~> 1.0): Event emission for observability
- **briefly** (~> 0.4): Test-only dependency for temporary files
- **ex_doc**: Dev-only for documentation generation
- **credo** (~> 1.7): Dev/test-only for static code analysis
- **dialyxir** (~> 1.4): Dev/test-only for Dialyzer integration and type checking

## Code Quality Tools

### Credo
Credo performs static code analysis to enforce Elixir style guidelines and identify code smells. Configuration in `.credo.exs`.

Current known issues to address:
- Code readability: Number formatting (use underscores for large numbers), sigil usage, alias ordering
- Refactoring: Use `Enum.map_join/3` instead of `Enum.map/2 |> Enum.join/2`, reduce function complexity and nesting depth
- Warnings: Struct specifications in `@spec` declarations

### Dialyzer
Dialyzer performs static type analysis to catch type errors and inconsistencies. PLT (Persistent Lookup Table) stored in `apps/http_fetch/priv/plts/dialyzer.plt`.

Current known issues to address:
- `HTTP.fetch/2`: Spec doesn't match success typing due to Task.Supervisor return inference
- `HTTP.Promise.then/3`: Opaque type violations with Task struct

## Requirements
- Elixir 1.18+ (for built-in `JSON` module support)
- Erlang OTP with `:ssl` and `:public_key` applications
