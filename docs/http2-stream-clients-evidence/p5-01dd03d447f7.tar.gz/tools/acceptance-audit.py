#!/usr/bin/env python3
"""Read-only audit of completed P5 evidence. Does not execute any workloads.

SSE EOF/Open counts are asserted by the frozen public gate contract, corroborated
by ordered peer requests/ranges; they are not directly printed counters. SSE
final quiescence likewise combines its last owner-only sample with the gate's
settle-before-PASS contract. These evidence limits are reported explicitly.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import shlex
import sys

SSE_BUDGETS = dict(owner_heap_bytes=8388608, owner_binary_bytes=2097152,
    owner_active_mailbox=256, owner_quiescent_mailbox=16, session_heap_bytes=8388608,
    session_binary_bytes=4194304, session_mailbox=256, stream_heap_bytes=8388608,
    stream_binary_bytes=4194304, stream_mailbox=256, monitor_heap_bytes=65536,
    monitor_binary_bytes=65536, monitor_workers=8, owners=4, stream_workers=8,
    queue_bytes=2097152, queue_events=1024)
WS_BUDGETS = dict(owners=4, workers=8, sessions=8, monitor_workers=8,
    monitor_heap_bytes=65536, monitor_binary_bytes=65536, heap_bytes=8388608,
    binary_bytes=4194304, mailbox=256, queue_bytes=1048576, queue_events=64,
    send_bytes=1048576, send_frames=16, control_frames=16, raw_bytes=1048576)
METRICS = ('heap_bytes', 'binary_bytes', 'mailbox')
INTERVALS = ['slow-consumer', 'cancellation', 'draining']


def fetch_names():
    names = set('final-deps final-compile final-format final-full-tests final-credo final-dialyzer final-hpack final-external-consumer final-exssl-feature-consumer final-tls-lifecycle-ci final-runtime-regressions final-environment'.split())
    names.update(f'final-cold-fetch-repeat-{n}' for n in range(1, 4))
    names.update(f'final-{mode}-{peer}-{route}' for peer in ('hyper-h2', 'node')
                 for route in ('h2c', 'tls-ssl', 'tls-ex_ssl')
                 for mode in ('smoke', 'transfer', 'concurrent'))
    names.update(f'final-reuse-{peer}-limit-{limit}' for peer in ('hyper-h2', 'node') for limit in (1, 2, 100))
    return names | {'final-package-tls-ssl', 'final-package-tls-ex_ssl', 'final-soak'}


def new_names():
    names = {f'sse-{peer}-{route}-{mode}' for peer in ('hyper-h2', 'node')
             for route in ('h2c', 'ssl', 'ex_ssl') for mode in ('sse', 'mixed', 'faults')}
    names.update(f'sse-{peer}-churn' for peer in ('hyper-h2', 'node'))
    names.update(f'ws-{route}-{mode}' for route in ('h2c', 'ssl', 'ex_ssl') for mode in ('echo', 'mixed', 'faults'))
    names.update(f'ws-node-{route}-mixed' for route in ('h2c', 'ssl', 'ex_ssl'))
    return names | {'ws-churn', 'package-traffic', 'docs', 'mixed-soak'}


class AuditError(Exception):
    pass


def check(condition, message):
    if not condition:
        raise AuditError(message)


def integer(value):
    return type(value) is int and value >= 0


def one(records, predicate, label):
    selected = [record for record in records if predicate(record)]
    check(len(selected) == 1, f'{label}: expected exactly one record, got {len(selected)}')
    return selected[0]


def kind(records, name):
    return [record for record in records if record.get('kind') == name]


def completed(records, mode):
    return one(records, lambda r: r.get('result') == 'PASS' and r.get('mode') == mode,
               f'{mode} public workload PASS')


def read_log(path):
    content = path.read_bytes()
    text = content.decode('utf-8', errors='replace')
    records = []
    for line in text.splitlines():
        try:
            record = json.loads(line)
        except ValueError:
            continue
        if isinstance(record, dict):
            records.append(record)
    check(not any('peer_error' in record for record in records), f'{path.name}: peer error')
    return text, records, hashlib.sha256(content).hexdigest()


def footer(text, status, elapsed):
    check(re.findall(r'^exit_status=(-?\d+)$', text, re.M) == [str(status)], 'missing/duplicate/mismatched exit footer')
    check(re.findall(r'^elapsed_ms=(\d+)$', text, re.M) == [str(elapsed)], 'missing/duplicate/mismatched elapsed footer')


def source_provenance(records, manifest, websocket=False):
    label = 'fixture_provenance' if websocket else 'provenance'
    provenance = one(records, lambda r: r.get('kind') == label, label)
    hashes = provenance['source_sha256'] if websocket else provenance['sources']
    check(bool(hashes), 'empty fixture source hashes')
    for name, digest in hashes.items():
        path = name if name.startswith('scripts/') else 'scripts/' + name
        check(manifest.get(path) == digest, f'fixture source differs from frozen manifest: {path}')
    if not websocket:
        check(provenance.get('dirty_files') == [], 'SSE candidate reports dirty source')
        ready = one(records, lambda r: r.get('kind') == 'ready', 'SSE peer readiness')
        if provenance['peer'] == 'node':
            check(ready.get('node') == '24.19.0' and ready.get('nghttp2') == '1.69.0', 'SSE Node peer versions drifted')
        else:
            check(ready.get('version') == '4.2.0', 'SSE hyper-h2 peer version drifted')
    else:
        versions = provenance['versions']
        check(all(versions.get(key) == value for key, value in
              dict(h2='4.2.0', hpack='4.1.0', hyperframe='6.1.0', wsproto='1.2.0').items()), 'WS peer version drift')
        if provenance.get('peer') == 'node':
            check(versions.get('node') == '24.19.0' and versions.get('nghttp2') == '1.69.0', 'Node peer version drift')
    return provenance


def resources(records, public, websocket=False):
    expected = WS_BUDGETS if websocket else SSE_BUDGETS
    frozen = one(records, lambda r: r.get('kind') == 'frozen_budgets', 'frozen budgets')
    check(frozen['budgets'] == expected, 'frozen budgets changed')
    samples = kind(records, 'resource_sample')
    check(bool(samples), 'no resource samples')
    check(public['resource_samples' if websocket else 'samples'] == len(samples), 'resource sample count mismatch')
    maxima = dict.fromkeys(METRICS, 0) if websocket else {role: dict.fromkeys(METRICS, 0) for role in ('owner', 'session', 'stream', 'monitor')}
    for sample in samples:
        for key, limit in [('owners', expected['owners']), ('workers', expected['workers' if websocket else 'stream_workers']), ('monitor_workers', expected['monitor_workers'])]:
            check(integer(sample.get(key)) and sample[key] <= limit, f'{key} count exceeds frozen budget')
        if websocket:
            check(integer(sample.get('sessions')) and sample['sessions'] <= expected['sessions'], 'session count bound')
        for process in sample['processes']:
            for metric in METRICS:
                check(integer(process.get(metric)), f'invalid process {metric}')
            if websocket:
                monitor = process.get('role') == 'owner_monitor'
                limits = {'heap_bytes': expected['monitor_heap_bytes' if monitor else 'heap_bytes'],
                          'binary_bytes': expected['monitor_binary_bytes' if monitor else 'binary_bytes'], 'mailbox': expected['mailbox']}
                target = maxima
            else:
                role = process['role']
                check(role in maxima, 'unknown SSE process role')
                limits = {'heap_bytes': expected[role + '_heap_bytes'], 'binary_bytes': expected[role + '_binary_bytes'],
                          'mailbox': expected['owner_active_mailbox' if role == 'owner' else 'session_mailbox']}
                target = maxima[role]
            for metric in METRICS:
                check(process[metric] <= limits[metric], f'process {metric} exceeds frozen budget')
                target[metric] = max(target[metric], process[metric])
    check(public['sampled_maxima'] == maxima, 'reported maxima differ from actual resource samples')
    final = samples[-1]
    check(final['workers'] == final['monitor_workers'] == 0, 'final runtime workers/monitors remain')
    if websocket:
        check(final.get('quiescent') is True and final['sessions'] == 0, 'final WS quiescence/session cleanup absent')
    else:
        check(all(p.get('role') == 'owner' and p['mailbox'] <= expected['owner_quiescent_mailbox'] for p in final['processes']), 'final SSE sample contains sessions/stream workers or nonquiescent owner')
    return dict(frozen_budgets=expected, samples=len(samples), sampled_maxima=maxima, final=final,
                quiescence_basis='explicit WS flag and public settle contract' if websocket else 'last owner-only sample and public settle-before-PASS contract')


def protocol(records, tls):
    connections = kind(records, 'connection')
    check(bool(connections), 'missing actual connection evidence')
    check(all(r.get('protocol') == ('h2' if tls else 'h2c') and (not tls or r.get('alpn') == 'h2') for r in connections), 'actual HTTP/2/ALPN mismatch')
    return connections


def audit_sse(records, mode, count, tls, manifest):
    public = completed(records, mode)
    check(public.get('count') == count and integer(public.get('elapsed_ms')), 'SSE public configuration/timing mismatch')
    wire = completed(records, 'wire-audit')
    check(wire.get('public_client') is True and wire.get('observations', 0) > 0, 'SSE independent wire PASS absent')
    provenance = source_provenance(records, manifest)
    connections = protocol(records, tls)
    check(bool(kind(records, 'settings')), 'SSE missing independent SETTINGS')
    summary = dict(mode=mode, elapsed_ms=public['elapsed_ms'], peer=provenance['peer'], tls=tls,
                   resources=resources(records, public), wire_observations=wire['observations'], fixture_provenance=provenance)
    requests = kind(records, 'request')
    if mode in ('sse', 'churn'):
        endpoint = '/sse/churn' if mode == 'churn' else '/sse/numbered'
        numbered = [r for r in requests if r.get('endpoint') == endpoint]
        cursors = [str(n) if n else '' for n in range(count)] if mode == 'churn' else ['', str(count // 2)]
        check([r.get('cursor') for r in numbered] == cursors, 'SSE ordered cursor/open count mismatch')
        check(len({r['connection'] for r in numbered}) == 1, 'SSE reconnects did not reuse one connection')
        ranges = kind(records, 'range_complete')
        matched = [r for r in ranges if (r['connection'], r['stream']) in {(q['connection'], q['stream']) for q in numbered}]
        expected = [(n, n, 1) for n in range(1, count + 1)] if mode == 'churn' else [(1, count // 2, count // 2), (count // 2 + 1, count, count - count // 2)]
        check([(r.get('first'), r.get('last'), r.get('count')) for r in matched] == expected, 'SSE peer range completion mismatch')
        summary.update(events=sum(r['count'] for r in matched), actual_opens=len(numbered),
                       eof_reconnects_contract_asserted=count - 1 if mode == 'churn' else 1,
                       eof_proof='frozen public receive_numbered validates exact EOF/Open counts; ordered peer cursors/ranges corroborate')
        if mode == 'sse':
            check(count == 10000, 'SSE final event workload is not 10000')
            check(len(kind(records, 'semantics_triggered')) == 1, 'missing controlled semantics EOF')
            overflow = one(records, lambda r: r.get('kind') == 'overflow_triggered', 'controlled overflow')
            check(overflow.get('lines') == 1024 and overflow.get('line_bytes') == 71, 'overflow wire payload mismatch')
            pressure = [r for r in requests if r.get('endpoint') == '/sse/pressure']
            siblings = [r for r in requests if r.get('endpoint') in ('/fetch/paused', '/fetch/after-pause')]
            check(len(pressure) == 1 and len(siblings) == 2 and len({r['connection'] for r in pressure + siblings}) == 1, 'paused SSE/sibling isolation evidence mismatch')
        else:
            check(count == 1001, 'SSE churn final workload requires 1001 opens')
    elif mode == 'mixed':
        mixed = [r for r in requests if r.get('endpoint') in ('/sse/hold', '/control/held') or r.get('endpoint', '').startswith('/fetch/')]
        check(bool(mixed) and len({r['connection'] for r in mixed}) == 1, 'SSE/Fetch shared connection absent')
        summary['volume_note'] = 'count is configuration only; mixed is not a 10000-event workload'
    else:
        summary['volume_note'] = 'count is configuration only; faults is not a 10000-event workload'
    return summary


def audit_ws(records, mode, count, tls, manifest):
    public = completed(records, mode)
    check(public.get('completed') is True and public.get('acceptance') is True and public.get('count') == count, 'WS completed acceptance marker absent')
    wire = completed(records, 'wire-audit')
    check(wire.get('completed') is True and wire.get('acceptance') is True and wire.get('public_client') is True and wire.get('requested_mode') == mode and wire.get('count') == count, 'WS independent wire completion mismatch')
    provenance = source_provenance(records, manifest, True)
    connections = protocol(records, tls)
    connects, clean = kind(records, 'connect'), kind(records, 'wire_complete')
    check(bool(connects) and all(r.get('wire_oracle') == 'PASS' and r.get('initial_end_stream') is False for r in connects), 'RFC8441 initial header/END_STREAM oracle absent')
    for record in clean:
        check(record.get('client_end_stream') is True and record.get('peer_end_stream') is True and record.get('client_close_code') == 1000 and record.get('retained_frame_bytes') == 0, 'unclean wire completion')
        check(record.get('masked_frames') == sum(record.get('client_frames', {}).values()), 'client mask/frame count mismatch')
    summary = dict(mode=mode, peer=provenance.get('peer', 'hyper-h2'), tls=tls, elapsed_ms=public['elapsed_ms'],
                   resources=resources(records, public, True), actual_connections=len(connections), clean_wire_sessions=wire['clean_wire_sessions'], fixture_provenance=provenance)
    if mode == 'echo':
        check(count == 10000 and len(clean) == 1 and clean[0]['messages'] == 10001, 'WS 10000 plus extra payload not completed')
        check(clean[0]['maximum_client_payload'] > 65535 and clean[0]['client_frames'].get('1', 0) > 0 and clean[0]['client_frames'].get('2', 0) > 0, 'WS large/text/binary wire proof absent')
        summary.update(messages=clean[0]['messages'], ordinary_echo_messages=10000, extra_large_messages=1, maximum_client_payload=clean[0]['maximum_client_payload'])
    elif mode == 'churn':
        check(count == 1000 and len(connects) == len(clean) == wire['clean_wire_sessions'] == 1000, 'WS actual churn count mismatch')
        check(all(r['messages'] == 1 for r in clean) and len({r['connection'] for r in connects}) == 1, 'WS churn messages/reuse mismatch')
        summary.update(actual_opens=1000, clean_cycles=1000, messages=1000)
    elif mode == 'mixed':
        mixed = [r for r in records if r.get('kind') in ('connect', 'sse', 'fetch', 'control')]
        check(len(connections) == 1 and len({r['connection'] for r in mixed}) == 1, 'mixed Fetch/SSE/WS one connection proof absent')
        check(len(kind(records, 'sse')) >= 2 and len(connects) >= 3 and any(r.get('case') == 'pressure' for r in connects), 'mixed stream/pressure oracle absent')
        check(len(clean) == wire['clean_wire_sessions'] == 3 and sorted(r['messages'] for r in clean) == [0, 1, 2], 'mixed clean/message counts mismatch')
        summary.update(messages=sum(r['messages'] for r in clean), volume_note='mixed count is configuration only, not 10000 exchanges')
    elif mode == 'faults':
        check({r.get('case') for r in kind(records, 'fault_triggered')} == {'malformed', 'oversized', 'parts'}, 'WS deterministic fault triggers missing')
        for name in ('server_reset', 'server_goaway', 'client_pong', 'credit_resumed', 'capability_enabled'):
            check(bool(kind(records, name)), f'WS fault oracle missing {name}')
        check(wire['clean_wire_sessions'] >= 1, 'WS fault surviving clean sessions absent')
        summary['volume_note'] = 'fault count is configuration only, not 10000 exchanges; peer labels are retained internally by the frozen wire oracle'
    elif mode == 'soak':
        check(public.get('active_elapsed_ms', 0) >= 1800000 and public.get('elapsed_ms', 0) >= 1800000 and wire.get('elapsed_soak_seconds') == 1800, 'mixed soak shorter than 1800 seconds')
        check(public.get('intervals') == INTERVALS, 'mixed soak intervals missing/out of order')
        cancelled = [r for r in kind(records, 'client_reset') if r.get('case') == 'cancel']
        check(len(cancelled) == 1 and cancelled[0]['code'] == 8, 'controlled soak tunnel cancellation absent')
        check(len(clean) == len(connects) - 1 and wire['clean_wire_sessions'] == len(clean), 'surviving soak tunnels did not complete')
        check(all((r['connection'], r['stream']) != (cancelled[0]['connection'], cancelled[0]['stream']) for r in clean), 'cancelled tunnel falsely clean')
        check(sum(r['messages'] for r in clean + cancelled) == public['ws_messages'], 'soak actual WS message count mismatch')
        ticks, sources, fetches = kind(records, 'soak_tick'), kind(records, 'sse'), kind(records, 'fetch')
        check(len(ticks) == public['sse_ticks'] > 0 and all(r['sse_streams'] == 2 and r['active_ws'] >= 2 for r in ticks), 'soak long-lived SSE/WS tick proof absent')
        check(len(sources) == 4 and public['sse_messages'] == len(sources) + 2 * len(ticks) and len(fetches) == public['fetch_requests'] > 0, 'soak SSE/Fetch counts mismatch')
        check(len(kind(records, 'server_goaway')) == 1 and len(connections) == 2 and len([r for r in connects if r.get('case') == 'pressure']) == 1, 'soak draining/replacement/pressure wire oracle absent')
        progress = kind(records, 'soak_progress')
        check(bool(progress) and [r['tick'] for r in progress] == list(range(1, len(progress) + 1)), 'soak progress ticks missing/duplicated')
        check(all(r.get('sse_sessions') == 2 and r.get('ws_sessions', 0) >= 2 and r.get('intervals') == INTERVALS[:len(r.get('intervals', []))] for r in progress), 'soak active sessions/interval progress mismatch')
        check([r['elapsed_ms'] for r in progress] == sorted(r['elapsed_ms'] for r in progress) and progress[-1]['intervals'] == INTERVALS, 'soak interval progress ordering missing')
        for interval, threshold in zip(INTERVALS, (450000, 900000, 1350000)):
            first = next(r for r in progress if interval in r['intervals'])
            check(first['elapsed_ms'] >= threshold, f'soak {interval} interval occurred before scheduled threshold')
        check(any(r['ws_sessions'] == 3 and r['intervals'] == ['slow-consumer'] for r in progress), 'slow-consumer active pressure session proof absent')
        check(any(r['ws_sessions'] == 2 and r['intervals'] == ['slow-consumer'] and r['elapsed_ms'] >= 453000 for r in progress), 'slow-consumer release after scheduled pause proof absent')
        summary.update(active_elapsed_ms=public['active_elapsed_ms'], intervals=public['intervals'], ws_messages=public['ws_messages'], sse_messages=public['sse_messages'], sse_ticks=public['sse_ticks'], fetch_requests=public['fetch_requests'], progress_samples=len(progress))
    return summary


def fetch_resources(records, mode):
    public = completed(records, mode)
    check(public.get('reservations') == 0, 'Fetch final reservations remain')
    snapshots = [r for r in records if r.get('gate') == 'resource_snapshot']
    check(len(snapshots) == 1, 'Fetch final resource snapshot absent/duplicated')
    for sample in snapshots + [r for r in records if r.get('gate') == 'soak_sample']:
        check(sample.get('pool_keys', 2) <= 1 and len(sample.get('owners', [])) <= 4, 'Fetch pool/owner bounds exceeded')
        for owner in sample['owners']:
            check(owner.get('active_streams') == owner.get('protocol_streams') == 0 and owner['mailbox'] <= 16 and owner['heap_bytes'] <= 8388608 and owner['binary_bytes'] <= 2097152, 'Fetch quiescent owner bound exceeded')
    summary = dict(mode=mode, elapsed_ms=public['elapsed_ms'], final=public, resource_snapshot=snapshots[0])
    if mode == 'soak':
        check(public.get('elapsed_ms', 0) >= 1800000, 'Fetch actual soak marker shorter than 1800 seconds')
        workload = one(records, lambda r: r.get('gate') == 'soak_workload', 'Fetch soak workload')
        check(workload.get('batches', 0) > 0 and workload.get('requests') == workload['batches'] * 16 and workload.get('seed') == 0, 'Fetch actual batch/request workload proof absent')
        samples = [r for r in records if r.get('gate') == 'soak_sample']
        check(bool(samples) and all(r['batch'] % 100 == 0 for r in samples), 'Fetch soak samples absent')
        check([r['batch'] for r in samples] == list(range(100, samples[-1]['batch'] + 1, 100)) and samples[-1]['batch'] <= workload['batches'], 'Fetch soak batch sample progression mismatch')
        check([r['elapsed_ms'] for r in samples] == sorted(r['elapsed_ms'] for r in samples) and all(r['elapsed_ms'] <= public['elapsed_ms'] for r in samples), 'Fetch soak sample timings invalid')
        summary.update(workload=workload, sampled_resource_maxima={metric: max((owner[metric] for sample in samples + snapshots for owner in sample['owners']), default=0) for metric in METRICS}, resource_samples=len(samples))
    return summary


def option(command, flag, default=None):
    return command[command.index(flag) + 1] if flag in command else default


def audit(evidence, parentlog):
    errors, gates, hashes = [], {}, {}
    def attempt(label, function):
        try:
            return function()
        except (AuditError, OSError, ValueError, KeyError, TypeError, IndexError) as error:
            errors.append(f'{label}: {error}')
            return None
    parent_text, parent_records, parent_hash = read_log(parentlog)
    parent = attempt('parent completion', lambda: one(parent_records, lambda r: r.get('result') == 'PASS' and r.get('completed') is True and r.get('fetch_gates') == 42 and r.get('new_gates') == 36 and r.get('requested_soak_seconds') == 1800, 'parent completed 42+36 PASS'))
    if parent:
        attempt('parent final marker', lambda: check(parent_records[-1] == parent, 'parent PASS is not final JSON record'))
    if re.search(r'KeyboardInterrupt|Traceback \(most recent call last\)|remaining gates NOT RUN|FAIL:|FAIL or NOT RUN', parent_text):
        errors.append('parent log contains interruption/failure')
    manifest = json.loads((evidence/'source-manifest.json').read_text())
    check(bool(manifest) and all(re.fullmatch(r'[0-9a-f]{64}', value) for value in manifest.values()), 'invalid source manifest')
    commands = json.loads((evidence/'commands.json').read_text())
    fetch_commands = json.loads((evidence/'fetch42/commands.json').read_text())
    attempt('new gate inventory', lambda: check(set(commands) == new_names() | {'fetch42'}, 'expected exact 36 new gates plus Fetch42'))
    attempt('Fetch gate inventory', lambda: check(set(fetch_commands) == fetch_names(), 'expected exact original 42 Fetch gate names'))
    attempt('new result inventory', lambda: check({path.name.removesuffix('.result.json') for path in evidence.glob('*.result.json')} == new_names() | {'fetch42', 'prepare-deps', 'prepare-compile'}, 'expected exactly 36 new result JSONs plus Fetch42/preparation'))
    ledger = []
    for line in (evidence/'fetch42/results.tsv').read_text().splitlines():
        fields = line.split('\t')
        check(len(fields) == 4, 'malformed Fetch ledger row')
        ledger.append(dict(gate=fields[0], status=int(fields[1]), elapsed_ms=int(fields[2]), tree=fields[3]))
    trees = {row['tree'] for row in ledger}
    if parent:
        trees.add(parent['candidate_tree'])
    check(len(trees) == 1 and re.fullmatch(r'[0-9a-f]{40}', next(iter(trees))), 'candidate tree provenance disagreement')
    tree = next(iter(trees))
    attempt('Fetch ledger', lambda: check(len(ledger) == 42 and Counter(row['gate'] for row in ledger) == Counter(fetch_names()) and all(row['status'] == 0 for row in ledger), 'exact 42 successful unique Fetch ledger gates required'))
    for row in ledger:
        def check_fetch(row=row):
            text, records, digest = read_log(evidence/'fetch42'/f"{row['gate']}.log")
            footer(text, row['status'], row['elapsed_ms'])
            check(f'candidate_tree={tree}\n' in text, 'Fetch log candidate header mismatch')
            hashes['fetch42/'+row['gate']+'.log'] = digest
            command = fetch_commands.get(row['gate'], [])
            check('command=' + shlex.join(command) + '\n' in text, 'Fetch executed command differs from inventory')
            mode = option(command, '--mode')
            if mode:
                expected_mode = 'soak' if row['gate'] == 'final-soak' else ('smoke' if row['gate'].startswith('final-package-') else row['gate'].split('-')[1])
                expected_peer = 'node' if '-node-' in row['gate'] or row['gate'] == 'final-soak' else 'hyper-h2'
                tls = '-tls-' in row['gate'] or row['gate'] == 'final-soak'
                backend = 'ex_ssl' if row['gate'].endswith('ex_ssl') or row['gate'] == 'final-soak' else 'ssl'
                check(mode == expected_mode and option(command, '--peer') == expected_peer and ('--tls' in command) == tls and option(command, '--backend', 'ssl') == backend, 'Fetch named peer/route/mode command mismatch')
                if mode == 'reuse':
                    check(option(command, '--count') == '10000' and option(command, '--limit') == row['gate'].rsplit('-', 1)[1], 'Fetch reuse workload reduced')
                if mode == 'soak':
                    check(option(command, '--seconds') == '1800' and row['elapsed_ms'] >= 1800000, 'Fetch soak command/wall time reduced')
            if mode:
                metadata = one(records, lambda r: 'candidate_tree' in r and 'working_tree_dirty' in r, 'Fetch wire/source provenance')
                check(metadata['candidate_tree'] == tree and metadata['working_tree_dirty'] is False, 'Fetch wire/source candidate drift')
            data = fetch_resources(records, mode) if mode else ({'environment_records': records} if row['gate'] == 'final-environment' else {})
            if mode:
                check(row['elapsed_ms'] + 50 >= data['elapsed_ms'], 'Fetch runner wall time shorter than workload time')
            return dict(exit_status=row['status'], elapsed_ms=row['elapsed_ms'], **({'workload': data} if data else {}))
        result = attempt(row['gate'], check_fetch)
        if result is not None:
            gates[row['gate']] = result
    for name in sorted(new_names() | {'fetch42', 'prepare-deps', 'prepare-compile'}):
        def check_new(name=name):
            result = json.loads((evidence/f'{name}.result.json').read_text())
            check(result.get('gate') == name and result.get('exit_status') == 0 and result.get('candidate_tree') == tree and integer(result.get('elapsed_ms')), 'result identity/exit/timing mismatch')
            text, records, digest = read_log(evidence/f'{name}.log')
            check(result.get('log_sha256') == digest, 'result log SHA256 mismatch')
            check(f'candidate_tree={tree}\n' in text, 'new gate log candidate header mismatch')
            footer(text, 0, result['elapsed_ms'])
            hashes[name+'.log'] = digest
            command = commands.get(name, ['mix', 'deps.get', '--check-locked'] if name == 'prepare-deps' else ['mix', 'compile', '--warnings-as-errors'] if name == 'prepare-compile' else [])
            check('command=' + shlex.join(command) + '\n' in text, 'new executed command differs from inventory')
            mode = option(command, '--mode')
            tls = '--tls' in command
            count = int(option(command, '--count', '10000'))
            if name.startswith(('sse-', 'ws-')) or name == 'mixed-soak':
                expected_mode = 'soak' if name == 'mixed-soak' else name.rsplit('-', 1)[1]
                expected_tls = name == 'mixed-soak' or '-ssl-' in name or '-ex_ssl-' in name
                expected_backend = 'ex_ssl' if name == 'mixed-soak' or '-ex_ssl-' in name else 'ssl'
                expected_peer = 'node' if name.startswith(('sse-node-', 'ws-node-')) else 'hyper-h2'
                check(mode == expected_mode and tls == expected_tls and option(command, '--backend', 'ssl') == expected_backend and option(command, '--peer', 'hyper-h2') == expected_peer, 'named new gate peer/route/mode command mismatch')
            if name == 'docs':
                check('MIX_ENV=dev' in command and any(item.startswith('MIX_BUILD_PATH=') and item.endswith('/docs-build') for item in command), 'docs lacks separate dev build')
            if name.startswith('sse-'):
                data = audit_sse(records, mode, count, tls, manifest)
            elif name.startswith('ws-') or name == 'mixed-soak':
                data = audit_ws(records, mode, count, tls, manifest)
            elif name == 'package-traffic':
                data = one(records, lambda r: r.get('gate') == 'isolated_package_http2_traffic' and r.get('result') == 'PASS', 'package traffic completed PASS')
                check(data.get('completed') is True and data.get('packages') == 7 and data.get('consumers') == data.get('connections') == 4 and data.get('mixed_shared_connection') is True, 'seven-package/four-consumer traffic marker absent')
                consumer_markers = [r for r in records if r.get('gate') == 'isolated_runtime_startup' and r.get('result') == 'PASS']
                check([r.get('clients') for r in consumer_markers] == [['http_fetch'], ['http_event_source'], ['http_web_socket'], ['http_fetch','http_event_source','http_web_socket']], 'four selected consumer startup proofs absent')
                check(all(r.get('runtime_children') == 3 and r.get('pool_keys') == 1 and r.get('fetch_visible') == ('http_fetch' in r['clients']) for r in consumer_markers), 'isolated consumer runtime/Fetch visibility proof mismatch')
                metadata = one(records, lambda r: r.get('gate') == 'original_package_metadata' and r.get('result') == 'PASS', 'original package metadata PASS')
                check(metadata.get('version') == '0.16.0' and set(metadata.get('packages', [])) == {'http_core','http_runtime','elixir_quic_http3','http_fetch','http_web_socket','http_event_source','http_web_transport'}, 'seven original package identities/versions mismatch')
                connections = protocol(records, False)
                check(len(connections) == 4, 'package traffic actual connection count mismatch')
                traffic = {}
                for record in records:
                    if record.get('kind') in ('fetch', 'sse', 'connect'):
                        traffic.setdefault(record['connection'], set()).add(record['kind'])
                check(list(traffic.values()) == [{'fetch'}, {'sse'}, {'connect'}, {'fetch','sse','connect'}], 'package actual standalone/mixed wire traffic mismatch')
                data = dict(data, metadata=metadata, consumer_startup=consumer_markers)
            else:
                data = {}
            if mode:
                check(result['elapsed_ms'] + 50 >= data['elapsed_ms'], 'new runner wall time shorter than workload time')
            if mode == 'soak':
                check(option(command, '--seconds') == '1800' and '--soak-check' not in command, 'acceptance command is short/developer soak')
                check(result['elapsed_ms'] >= 1800000, 'runner soak wall time too short')
            return dict(exit_status=0, runner_elapsed_ms=result['elapsed_ms'], **({'workload': data} if data else {}))
        result = attempt(name, check_new)
        if result is not None:
            gates[name] = result
    return dict(result='FAIL' if errors else 'PASS', completed=not errors, audit_only=True,
                evidence=str(evidence), parentlog=str(parentlog), candidate_tree=tree,
                expected_counts=dict(fetch_ledger=42, new_result_json=36, preparation=2, fetch42_wrapper=1),
                observed_counts=dict(fetch_ledger_rows=len(ledger), successful_fetch_ledger_rows=sum(r['status']==0 for r in ledger), validated_gates=len(gates)),
                errors=errors, parent_completion=parent, source_manifest_sha256=hashlib.sha256((evidence/'source-manifest.json').read_bytes()).hexdigest(),
                source_files=len(manifest), parent_log_sha256=parent_hash, log_sha256=hashes, gates=gates,
                limitations=['SSE EOF/Open counters are contract-asserted, corroborated by ordered wire ranges/cursors; not directly logged.', 'SSE final sample has no quiescent flag; owner-only cleanup sample and frozen settle-before-PASS contract are required.', 'This audits captured evidence and source hashes; it does not rerun workloads or verify remote CI/publication.'])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', required=True, type=Path)
    parser.add_argument('--parentlog', '--parent-log', required=True, type=Path)
    parser.add_argument('--output', type=Path)
    args=parser.parse_args()
    try:
        summary=audit(args.evidence.resolve(),args.parentlog.resolve())
    except (AuditError, OSError, ValueError, KeyError, TypeError, IndexError) as error:
        summary=dict(result='FAIL',completed=False,audit_only=True,evidence=str(args.evidence),errors=[str(error)])
    rendered=json.dumps(summary,indent=2)+'\n'
    if args.output:
        args.output.write_text(rendered)
    print(rendered,end='')
    return 0 if summary['result']=='PASS' else 1


if __name__=='__main__':
    raise SystemExit(main())
