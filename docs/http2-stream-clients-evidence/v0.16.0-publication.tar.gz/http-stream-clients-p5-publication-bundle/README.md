# v0.16.0 publication verification

Release workflow 36824021755 completed successfully on
69815b5aabaf6642865648c0c16f21294caf8952. All 842 tests + 20 doctests,
51 E2E tests, compile/format/Credo/Dialyzer/docs/package checks passed.
Seven packages and their docs were newly published, then the v0.16.0 tag and
GitHub release were created. The immutable tag remains on this release head.
Later publication-evidence commits change documentation only.

Accepted executable source: a80fd3d46a6aba9eadc43c789ad92fbf734081da,
tree99ed0ffd672f8fa0c23f118b5c298972d6971a21, accessible in the separate
p5-99ed0ffd672f.tar.gz acceptance archive, SHA256
2f05ccda052a68cae28a3d0c01afa5e9eb94c4a6054f35ec875279f1d02fdbe3.

hex-artifacts/ retains all seven API metadata records and original tarballs.
The independent audit verifies seven outer API SHA256 checksums, seven inner
CHECKSUMs, app/namespace/GitHub identities, eleven internal dependency edges,
and all 101 library files byte-identical to the accepted source. Exact checksums
are in audit.json and the independent report. Re-audit against accepted source:

    python3 release-audit.py --source /path/to/accepted-source \
      --evidence /tmp/fresh-hex-audit

The fresh Hex-only consumer log includes all four selected-only dependency
projects, real loaded package paths, exact lock snapshots/checksums and wire
traffic. Consumers use published ==0.16.0 packages and no path/Git pins or hidden
Fetch/ex_ssl dependency. The peer observes exactly four actual h2c connections:
Fetch-only, SSE-only, WS-only and all three on one shared connection. Mixed live
WS/SSE survive Fetch stop/restart. TLS backend traffic is separately proven by
the frozen full acceptance and published-ex_ssl provenance gates.

Full release workflow JSON/log, actual GitHub release metadata, evidence-head
CI/Test snapshots, dispatch, Git parity and final-doc audit are included.
The release parity snapshot shows release HEAD/local/origin/tag identical before
this publication-evidence commit; executable source remains identical afterward.
No production deployment was performed. Verify every regular file:

    sha256sum -c SHA256SUMS
