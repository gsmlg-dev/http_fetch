import argparse,hashlib,io,json,tarfile,urllib.request
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--evidence',type=Path,required=True);a=p.parse_args()
a.evidence.mkdir(parents=True,exist_ok=False)
apps=['http_core','http_runtime','elixir_quic_http3','http_fetch','http_web_socket','http_event_source','http_web_transport']
required={app:({'http_core':'~> 0.16.0'} if app!='http_core' else {}) for app in apps}
for app in ['http_fetch','http_event_source','http_web_socket']:required[app]['http_runtime']='~> 0.16.0'
for app in ['http_fetch','http_web_transport']:required[app]['elixir_quic_http3']='~> 0.16.0'
results=[]
for app in apps:
    url=f'https://hex.pm/api/packages/{app}/releases/0.16.0'
    raw=urllib.request.urlopen(url,timeout=30).read();release=json.loads(raw)
    (a.evidence/f'{app}-release.json').write_bytes(raw)
    package_raw=urllib.request.urlopen(f'https://hex.pm/api/packages/{app}',timeout=30).read()
    package=json.loads(package_raw);(a.evidence/f'{app}-package.json').write_bytes(package_raw)
    assert release['version']=='0.16.0'
    for dep,req in required[app].items():
        assert release['requirements'][dep]['app']==dep and release['requirements'][dep]['requirement']==req
        assert not release['requirements'][dep]['optional']
    assert package['meta']['links']['GitHub']=='https://github.com/gsmlg-dev/http_fetch',package['meta']['links']
    artifact=urllib.request.urlopen(f'https://repo.hex.pm/tarballs/{app}-0.16.0.tar',timeout=30).read()
    (a.evidence/f'{app}-0.16.0.tar').write_bytes(artifact)
    outer=hashlib.sha256(artifact).hexdigest();assert outer==release['checksum'],(app,outer,release['checksum'])
    with tarfile.open(fileobj=io.BytesIO(artifact)) as t:
        metadata=t.extractfile('metadata.config').read()
        assert ('{<<"app">>,<<"'+app+'">>}').encode() in metadata,(app,'metadata application identity')
        inner_parts=[t.extractfile(n).read() for n in ['VERSION','metadata.config','contents.tar.gz']]
        inner=hashlib.sha256(b''.join(inner_parts)).hexdigest()
        stored=t.extractfile('CHECKSUM').read().decode().strip().lower();assert inner==stored
    with tarfile.open(fileobj=io.BytesIO(inner_parts[-1]),mode='r:gz') as t:
        source_files={str(f.relative_to(a.source/'apps'/app)):f for f in (a.source/'apps'/app/'lib').rglob('*.ex')}
        packaged={n.name for n in t.getmembers() if n.isfile() and n.name.startswith('lib/') and n.name.endswith('.ex')}
        assert set(source_files)==packaged,(app,'library file inventory mismatch')
        for name,f in source_files.items():assert t.extractfile(name).read()==f.read_bytes(),(app,name,'source drift')
    results.append(dict(app=app,version='0.16.0',outer_sha256=outer,inner_sha256=inner,library_files=len(source_files),requirements=release['requirements'],url=url))
    print(json.dumps(results[-1]),flush=True)
(a.evidence/'audit.json').write_text(json.dumps(dict(result='PASS',packages=results,packaged_libraries_match_candidate=True),indent=2)+'\n')
print(json.dumps(dict(result='PASS',completed=True,packages=7,artifact_checksums=True,packaged_libraries_match_candidate=True)),flush=True)
